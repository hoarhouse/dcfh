// =============================================================================
// DCF UI SYSTEM - Navigation, Modals, Footer
// Uses dcf-core.js utilities
// Works independently of authentication system
// =============================================================================

console.log('🎨 DCF UI System Loading...');

// =============================================================================
// LOGO CONFIGURATION
// =============================================================================

const LOGO_CONFIG = {
    icon: {
        type: 'circle', // 'circle', 'image', or 'svg'
        color: '#000', // black circle
        size: '24px',
        imageUrl: null // or path to logo image if using image type
    },
    text: {
        full: 'Domus Communis',
        short: 'Domus Communis',
        abbrev: 'DC'
    },
    link: 'index.html', // Homepage link
    // Display mode based on page type
    displayMode: {
        launch: 'full', // Show full name on launch pages
        member: 'short', // Show short name on member pages
        mobile: 'abbrev' // Show abbreviation on mobile
    }
};

// =============================================================================
// DUAL NAVIGATION SYSTEM - Launch Menu vs Full Menu
// =============================================================================

// LAUNCH MENU - Simplified public navigation for Phase 1
const LAUNCH_MENU = [
    { id: 'home', text: 'Home', href: 'index.html', dropdown: false },
    { id: 'blog', text: 'Blog', href: 'blog/index.html', dropdown: false },
    { 
        id: 'initiatives',
        text: 'Initiatives', 
        href: 'initiatives/initiatives_home.html', 
        dropdown: true,
        items: [
            { id: 'peace', text: 'Peace Initiative', href: 'initiatives/peace/initiative_peace.html' },
            { id: 'education', text: 'Education Initiative', href: 'initiatives/education/initiative_education.html' },
            { id: 'health', text: 'Health Initiative', href: 'initiatives/health/initiative_health.html' },
            { id: 'research', text: 'Research Initiative', href: 'initiatives/research/initiative_research.html' }
        ]
    },
    { 
        id: 'values',
        text: 'Values', 
        href: 'public/dcf_values.html', 
        dropdown: true,
        items: [
            { id: 'values', text: 'Values', href: 'public/dcf_values.html' },
            { id: 'contact', text: 'Contact', href: 'public/dcf_contact.html' }
        ]
    },
    { 
        id: 'resources',
        text: 'Library', 
        href: 'public/dcf_ai_resources.html', 
    dropdown: true,
        items: [
            { id: 'library', text: 'Library', href: 'public/dcf_ai_resources.html' },
            { id: 'faqs', text: 'FAQs', href: 'faqs/index.html' }
        ]
    }
];

// FULL MENU - Complete member navigation for Phase 2
const FULL_MENU = [
    { text: 'Home', href: 'members/dcf_member_home.html', dropdown: false },
    { text: 'Members', href: 'members/dcf_members_directory.html', dropdown: false },
    { text: 'Projects', href: 'public/dcf_projects_public.html', dropdown: false },
    { text: 'Events', href: 'public/dcf_events_public.html', dropdown: false },
    { text: 'Library', href: 'public/dcf_resources_public.html', dropdown: false }
];

// List of pages that should show the LAUNCH_MENU
const LAUNCH_PAGES = [
    // Main pages
    'index.html',
    
    // Public pages
    'public/dcf_values.html',
    'public/dcf_contact.html',
    'public/dcf_ai_resources.html',
    'public/dcf_articles_library.html',
    'public/test-nav-footer.html',
    'public/1.html',
    'public/2.html',
    'public/3.html',
    'public/4.html',
    'public/5.html',
    'public/ai-ethics-philosophy.html',
    'public/pope-francis-technology.html',
    'public/pope-leo-technology.html',
    'public/search-results.html',
    'public/warfare-security.html',
    'public/work-economy.html',
    
    // ALL Initiative pages - matches any file in initiatives folder and subfolders
    'initiatives/',  // This includes all 7 HTML files: initiatives_home, 4 initiative pages, and 2 nuclear disarmament pages
    
    // ALL Blog pages - matches any file in blog folder
    'blog/',
    
    // FAQ pages
    'faqs/',
    
    // Vatican resource pages
    'vatican-resources/',
    
    // Resources pages
    'resources/',
    
    // Donation page
    'members/dcf_donate.html'
];

// Function to detect if current page should use LAUNCH_MENU
function isLaunchPage() {
    const currentPath = window.location.pathname;
    const filename = currentPath.split('/').pop();
    
    // Check if current page is in launch pages list
    const isLaunch = LAUNCH_PAGES.some(page => {
        // Handle folder matches (like blog/, initiatives/)
        if (page.endsWith('/')) {
            const matches = currentPath.includes(page);
            if (matches) {
                console.log(`📁 Folder match found: "${page}" in path "${currentPath}"`);
            }
            return matches;
        }
        // Handle exact filename matches
        return currentPath.includes(page) || filename === page;
    });
    
    // Enhanced logging for blog pages
    if (currentPath.includes('/blog/')) {
        console.log('📝 Blog page detected:', {
            path: currentPath,
            file: filename,
            recognized: isLaunch ? '✅ YES - Launch Page' : '❌ NO - Member Page'
        });
    }
    
    console.log('🚀 Launch page check:', { 
        currentPath, 
        filename, 
        isLaunch,
        menuType: isLaunch ? 'LAUNCH MENU' : 'FULL MENU',
        matchedBy: isLaunch ? 'Matched by LAUNCH_PAGES' : 'Default to FULL_MENU'
    });
    
    return isLaunch;
}

// =============================================================================
// 1. NAVIGATION SYSTEM
// =============================================================================


// =============================================================================
// NAV INJECTION - Creates full nav structure from scratch
// =============================================================================

function createAndInjectNavigation() {
    const header = document.getElementById('main-header') || document.querySelector('.header');
    if (!header) {
        console.log('❌ Header container #main-header not found');
        return false;
    }

    // Determine which menu to use
    const menuItems = isLaunchPage() ? LAUNCH_MENU : FULL_MENU;
    const menuType = isLaunchPage() ? 'LAUNCH' : 'FULL';
    
    console.log(`🎨 Creating ${menuType} navigation from scratch`);
    
    // Get base path for links
    const basePath = window.getCorrectBasePath();
    
    // Create full nav structure
    // Use absolute paths for GitHub Pages
    const siteRoot = window.location.hostname === 'localhost' ? '/' : '/dcfh/';
    
    const navHTML = `
        <nav class="nav-container">
            <a href="${basePath}index.html" class="logo">
                <div class="logo-icon"></div>
                <span class="logo-text">Domus Communis Foundation Hungary</span>
            </a>
            <ul class="nav-menu"></ul>
            <div class="user-menu">
                <div class="language-switcher" id="languageSwitcher"></div>
            </div>
        </nav>
    `;
    
    header.innerHTML = navHTML;
    console.log('✅ Nav structure injected into header');
    
    // Now populate the menu items - KEEP ORIGINAL CALL
    populateDCFNavigation();
    
    // Initialize language switcher dropdown
    initializeLanguageSwitcher();
    console.log('✅ Language switcher initialized');
    
    // Add share bar CSS and inject share bar
    addShareBarCSS();
    createAndInjectShareBar();
    console.log('✅ Share bar initialized');
    
    return true;
}


// =============================================================================
// SHARE BAR INJECTION - Creates social share sidebar
// =============================================================================

function createAndInjectShareBar() {
    // Check if share bar already exists
    if (document.getElementById('shareSidebar')) {
        console.log('✅ Share bar already exists');
        return;
    }
    
    // Don't show share bar on initiatives pages
    if (window.location.pathname.includes('/initiatives/')) {
        console.log('🚫 Initiatives page - skipping share bar');
        return;
    }
    
    const pageUrl = encodeURIComponent(window.location.href);
    const pageTitle = encodeURIComponent(document.title);
    
    const shareHTML = `
        <div class="share-sidebar" id="shareSidebar">
            <a href="#" class="share-btn share-twitter" data-share="twitter" title="Share on Twitter">
                <svg viewBox="0 0 24 24">
                    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                </svg>
            </a>
            <a href="#" class="share-btn share-facebook" data-share="facebook" title="Share on Facebook">
                <svg viewBox="0 0 24 24">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
            </a>
            <a href="#" class="share-btn share-linkedin" data-share="linkedin" title="Share on LinkedIn">
                <svg viewBox="0 0 24 24">
                    <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                </svg>
            </a>
            <a href="#" class="share-btn share-reddit" data-share="reddit" title="Share on Reddit">
                <svg viewBox="0 0 24 24">
                    <path d="M12 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0zm5.01 4.744c.688 0 1.25.561 1.25 1.249a1.25 1.25 0 0 1-2.498.056l-2.597-.547-.8 3.747c1.824.07 3.48.632 4.674 1.488.308-.309.73-.491 1.207-.491.968 0 1.754.786 1.754 1.754 0 .716-.435 1.333-1.01 1.614a3.111 3.111 0 0 1 .042.52c0 2.694-3.13 4.87-7.004 4.87-3.874 0-7.004-2.176-7.004-4.87 0-.183.015-.366.043-.534A1.748 1.748 0 0 1 4.028 12c0-.968.786-1.754 1.754-1.754.463 0 .898.196 1.207.49 1.207-.883 2.878-1.43 4.744-1.487l.885-4.182a.342.342 0 0 1 .14-.197.35.35 0 0 1 .238-.042l2.906.617a1.214 1.214 0 0 1 1.108-.701zM9.25 12C8.561 12 8 12.562 8 13.25c0 .687.561 1.248 1.25 1.248.687 0 1.248-.561 1.248-1.249 0-.688-.561-1.249-1.249-1.249zm5.5 0c-.687 0-1.248.561-1.248 1.25 0 .687.561 1.248 1.249 1.248.688 0 1.249-.561 1.249-1.249 0-.687-.562-1.249-1.25-1.249zm-5.466 3.99a.327.327 0 0 0-.231.094.33.33 0 0 0 0 .463c.842.842 2.484.913 2.961.913.477 0 2.105-.056 2.961-.913a.361.361 0 0 0 .029-.463.33.33 0 0 0-.464 0c-.547.533-1.684.73-2.512.73-.828 0-1.979-.196-2.512-.73a.326.326 0 0 0-.232-.095z"/>
                </svg>
            </a>
            <a href="#" class="share-btn share-whatsapp" data-share="whatsapp" title="Share on WhatsApp">
                <svg viewBox="0 0 24 24">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                </svg>
            </a>
            <a href="#" class="share-btn share-email" data-share="email" title="Share via Email">
                <svg viewBox="0 0 24 24">
                    <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/>
                </svg>
            </a>
            <a href="#" class="share-btn share-copy" data-share="copy" title="Copy Link">
                <svg viewBox="0 0 24 24">
                    <path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/>
                </svg>
            </a>
        </div>
    `;
    
    document.body.insertAdjacentHTML('afterbegin', shareHTML);
    console.log('✅ Share bar injected');
    
    // Initialize share bar functionality
    initializeShareBar();
}

function initializeShareBar() {
    const shareSidebar = document.getElementById('shareSidebar');
    if (!shareSidebar) return;
    
    const pageUrl = window.location.href;
    const pageTitle = document.title;
    
    // Show/hide on scroll
    window.addEventListener('scroll', function() {
        if (window.scrollY > 300) {
            shareSidebar.classList.add('visible');
        } else {
            shareSidebar.classList.remove('visible');
        }
    });
    
    // Handle share button clicks
    shareSidebar.addEventListener('click', function(e) {
        const btn = e.target.closest('.share-btn');
        if (!btn) return;
        
        e.preventDefault();
        const shareType = btn.dataset.share;
        
        switch(shareType) {
            case 'twitter':
                window.open(`https://twitter.com/intent/tweet?url=${encodeURIComponent(pageUrl)}&text=${encodeURIComponent(pageTitle)}`, '_blank', 'width=550,height=420');
                break;
            case 'facebook':
                window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(pageUrl)}`, '_blank', 'width=550,height=420');
                break;
            case 'linkedin':
                window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(pageUrl)}`, '_blank', 'width=550,height=420');
                break;
            case 'reddit':
                window.open(`https://reddit.com/submit?url=${encodeURIComponent(pageUrl)}&title=${encodeURIComponent(pageTitle)}`, '_blank', 'width=550,height=420');
                break;
            case 'whatsapp':
                window.open(`https://wa.me/?text=${encodeURIComponent(pageTitle + ' ' + pageUrl)}`, '_blank');
                break;
            case 'email':
                window.location.href = `mailto:?subject=${encodeURIComponent(pageTitle)}&body=${encodeURIComponent(pageUrl)}`;
                break;
            case 'copy':
                navigator.clipboard.writeText(pageUrl).then(() => alert('Link copied to clipboard!'));
                break;
        }
    });
    
    console.log('✅ Share bar initialized');
}


function populateDCFNavigation() {
    const navMenu = document.querySelector('.nav-menu');
    if (!navMenu) {
        console.log('❌ Navigation menu element not found');
        return;
    }

    // Determine which menu to use
    const menuItems = isLaunchPage() ? LAUNCH_MENU : FULL_MENU;
    const menuType = isLaunchPage() ? 'LAUNCH' : 'FULL';
    
    console.log(`🧭 Populating ${menuType} navigation menu with ${menuItems.length} items`);
    
    // Clear existing menu
    navMenu.innerHTML = '';
    console.log('🔥 CLEARED NAV MENU, NOW ADDING ITEMS...');
    
    // Get base path for links
    const basePath = window.getCorrectBasePath();
    
    // Build menu from config
    const siteRoot = window.location.hostname === 'localhost' ? '/' : '/dcfh/';
    console.log('🔥 USER MENU HTML BEFORE:', document.querySelector('.user-menu')?.outerHTML);
    menuItems.forEach(item => {
        const li = document.createElement('li');
        
        if (item.dropdown && item.items) {
            // Create dropdown container
            li.className = 'nav-dropdown';
            li.style.position = 'relative';
            
            // Create dropdown toggle link
            const toggle = document.createElement('a');
            toggle.href = siteRoot + item.href;
            toggle.className = 'dropdown-toggle';
            // Set English text as fallback
            toggle.textContent = item.text;
            // Add data-i18n attribute for translation
            if (item.id) {
                toggle.setAttribute('data-i18n', item.id);
            }
            
            // Add dropdown arrow
            const arrow = document.createElement('span');
            arrow.textContent = ' ▼';
            arrow.style.fontSize = '0.7em';
            arrow.style.marginLeft = '3px';
            toggle.appendChild(arrow);
            
            li.appendChild(toggle);
            
            // Create dropdown menu
            const dropdownMenu = document.createElement('ul');
            dropdownMenu.className = 'nav-submenu';
            dropdownMenu.style.cssText = `
                display: none;
                position: absolute;
                top: 100%;
                left: 0;
                background: white;
                border: 1px solid #e5e5e5;
                border-radius: 8px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.1);
                min-width: 220px;
                z-index: 1000;
                margin-top: 0;
                padding: 0.5rem 0;
                list-style: none;
            `;
            
            // Add dropdown items
            item.items.forEach(subItem => {
                const subLi = document.createElement('li');
                const link = document.createElement('a');
                link.href = siteRoot + subItem.href;
                // Set English text as fallback
                link.textContent = subItem.text;
                // Add data-i18n attribute for translation
                if (subItem.id) {
                    link.setAttribute('data-i18n', subItem.id);
                }
                link.style.cssText = `
                    display: block;
                    padding: 0.75rem 1.25rem;
                    color: #333;
                    text-decoration: none;
                    transition: background 0.2s ease;
                    white-space: nowrap;
                `;
                
                // Add hover effect
                link.addEventListener('mouseenter', () => {
                    link.style.background = '#f8f9fa';
                });
                link.addEventListener('mouseleave', () => {
                    link.style.background = 'transparent';
                });
                
                subLi.appendChild(link);
                dropdownMenu.appendChild(subLi);
            });
            
            li.appendChild(dropdownMenu);
            console.log('✅ Created dropdown for:', toggle.textContent, 'with', item.items.length, 'items'); // DEBUG LOG
            console.log('🔍 DROPDOWN HTML:', li.outerHTML); // FULL HTML DEBUG
            
            // Improved hover handling with delay
            let hoverTimeout;
            
            console.log('🎯 ATTACHING HOVER LISTENERS TO:', toggle.textContent, 'dropdown'); // CRITICAL DEBUG
            li.addEventListener('mouseenter', () => {
                console.log('🟢 HOVER ENTER on LI:', toggle.textContent); // DEBUG LOG
                clearTimeout(hoverTimeout);
                dropdownMenu.style.display = 'block';
                dropdownMenu.style.visibility = 'visible';
                dropdownMenu.style.opacity = '1';
            });
            
            li.addEventListener('mouseleave', (e) => {
                console.log('🔴 HOVER LEAVE from LI:', toggle.textContent); // DEBUG LOG
                // Small delay to allow cursor to reach submenu
                hoverTimeout = setTimeout(() => {
                    // Check if mouse is still within the dropdown area
                    if (!li.contains(e.relatedTarget)) {
                        dropdownMenu.style.display = 'none';
                        console.log('🔴 Set display to none after delay'); // DEBUG LOG
                    }
                }, 50);
            });
            
            // Keep menu open when hovering over it
            dropdownMenu.addEventListener('mouseenter', () => {
                console.log('🟢 HOVER ENTER on SUBMENU'); // DEBUG LOG
                clearTimeout(hoverTimeout);
                dropdownMenu.style.display = 'block';
            });
            
            dropdownMenu.addEventListener('mouseleave', () => {
                console.log('🟡 HOVER LEAVE from SUBMENU'); // DEBUG LOG
                dropdownMenu.style.display = 'none';
            });
            
            // Keyboard accessibility
            toggle.addEventListener('focus', () => {
                dropdownMenu.style.display = 'block';
            });
            toggle.addEventListener('blur', (e) => {
                // Check if focus moved to dropdown item
                setTimeout(() => {
                    if (!li.contains(document.activeElement)) {
                        dropdownMenu.style.display = 'none';
                    }
                }, 100);
            });
            
        } else {
            // Create regular menu item
            const link = document.createElement('a');
            link.href = siteRoot + item.href;
            // Set English text as fallback
            link.textContent = item.text;
            // Add data-i18n attribute for translation
            if (item.id) {
                link.setAttribute('data-i18n', item.id);
            }
            
            // Highlight active page
            if (window.location.pathname.includes(item.href)) {
                link.className = 'active';
            }
            
            li.appendChild(link);
        }
        
        navMenu.appendChild(li);
    });
    
    console.log(`✅ ${menuType} navigation populated with ${menuItems.length} items`);
    console.log('🔥 USER MENU HTML AFTER:', document.querySelector('.user-menu')?.outerHTML);
}

// Keep the old function for backward compatibility
function populateTopNavigation() {
    console.log('🧭 Populating DCF navigation (legacy call)...');
    populateDCFNavigation();
}

// Original navigation structure (preserved for reference)
function populateTopNavigationOld() {
    console.log('🧭 Populating DCF navigation (OLD VERSION)...');
    
    const navMenu = document.querySelector('.nav-menu');
    if (!navMenu) {
        console.log('❌ Navigation container (.nav-menu) not found');
        return;
    }
    
    // Clear existing navigation
    navMenu.innerHTML = '';
    
    const basePath = window.getCorrectBasePath();
    
    // DCF HUNGARY NAVIGATION STRUCTURE (logged out state)
    const navItems = [
        { 
            href: basePath + 'initiatives/initiatives_home.html', 
            text: 'Initiatives',
            dropdown: true,
            submenu: [
                { href: basePath + 'initiatives/peace/initiative_peace.html', text: 'Peace Initiative' },
                { href: basePath + 'initiatives/education/initiative_education.html', text: 'Education Initiative' },
                { href: basePath + 'initiatives/health/initiative_health.html', text: 'Health Initiative' },
                { href: basePath + 'initiatives/research/initiative_research.html', text: 'Research Initiative' }
            ]
        },
        { href: basePath + 'blog/index.html', text: 'Blog' },
        { href: basePath + 'people/index.html', text: 'People' },
        { 
            href: basePath + 'public/dcf_values.html', 
            text: 'Values',
            id: 'values',
            dropdown: true,
            submenu: [
                { href: basePath + 'public/dcf_values.html', text: 'Values', id: 'values' },
                { href: basePath + 'public/dcf_impact_report.html', text: 'Impact Report', id: 'impact_report' },
                { href: basePath + 'public/dcf_contact.html', text: 'Contact', id: 'contact' }
            ]
        },
        { href: basePath + 'public/dcf_projects_public.html', text: 'Projects' },
        { href: basePath + 'public/dcf_ai_resources.html', text: 'Library' },
    { href: basePath + 'news/dcf_news.html', 
            text: 'News',
            dropdown: true,
            submenu: [
                { href: basePath + 'news/dcf_news.html', text: 'Latest News' },
                { href: basePath + 'public/dcf_events_public.html', text: 'Events' }
            ]
        }
    ];
    
    navItems.forEach(item => {
        const li = document.createElement('li');
        
        if (item.dropdown && item.submenu) {
            // Create dropdown structure
            li.className = 'nav-dropdown';
            li.style.position = 'relative';
            
            const a = document.createElement('a');
            a.href = item.href;
            a.textContent = item.text;
            a.className = 'dropdown-toggle';
            
            // Add dropdown arrow
            const arrow = document.createElement('span');
            arrow.textContent = ' ▼';
            arrow.style.fontSize = '0.7em';
            arrow.style.marginLeft = '3px';
            a.appendChild(arrow);
            
            li.appendChild(a);
            
            // Create submenu
            const submenu = document.createElement('ul');
            submenu.className = 'nav-submenu';
            submenu.style.cssText = `
                display: none;
                position: absolute;
                top: 100%;
                left: 0;
                background: white;
                border: 1px solid #e5e5e5;
                border-radius: 8px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.1);
                min-width: 200px;
                z-index: 1000;
                padding: 0.5rem 0;
                margin-top: 0;
                list-style: none;
            `;
            
            item.submenu.forEach(subItem => {
                const subLi = document.createElement('li');
                subLi.style.margin = '0';
                
                const subA = document.createElement('a');
                subA.href = subItem.href;
                subA.textContent = subItem.text;
                subA.style.cssText = `
                    display: block;
                    padding: 0.5rem 1rem;
                    color: #666;
                    text-decoration: none;
                    transition: all 0.2s ease;
                    font-size: 0.9rem;
                `;
                
                // Add hover effect
                subA.addEventListener('mouseenter', () => {
                    subA.style.backgroundColor = '#f8f9fa';
                    subA.style.color = '#333';
                });
                subA.addEventListener('mouseleave', () => {
                    subA.style.backgroundColor = 'transparent';
                    subA.style.color = '#666';
                });
                
                subLi.appendChild(subA);
                submenu.appendChild(subLi);
            });
            
            li.appendChild(submenu);
            
            // Handle dropdown hover
            let hoverTimeout;
            
            li.addEventListener('mouseenter', () => {
                clearTimeout(hoverTimeout);
                submenu.style.display = 'block';
            });
            
            li.addEventListener('mouseleave', (e) => {
                // Small delay to allow cursor to reach submenu
                hoverTimeout = setTimeout(() => {
                    // Check if mouse is still within the dropdown area
                    if (!li.contains(e.relatedTarget)) {
                        submenu.style.display = 'none';
                    }
                }, 50);
            });
            
            // Keep submenu open when hovering over it
            submenu.addEventListener('mouseenter', () => {
                clearTimeout(hoverTimeout);
                submenu.style.display = 'block';
            });
            
            submenu.addEventListener('mouseleave', () => {
                submenu.style.display = 'none';
            });
            
        } else {
            // Regular menu item
            const a = document.createElement('a');
            a.href = item.href;
            a.textContent = item.text;
            li.appendChild(a);
        }
        
        navMenu.appendChild(li);
    });
    
    console.log('✅ DCF navigation populated with', navItems.length, 'items');
}

// =============================================================================
// TRANSLATION SYSTEM
// =============================================================================

const TRANSLATIONS = {}; // Store loaded translations
let currentLanguage = localStorage.getItem('dcf_preferred_language') || 'en';

/**
 * Load translation file for specified language
 * @param {string} lang - Language code (en, it, es, hu)
 */
async function loadTranslations(lang) {
    // Return cached translations if already loaded
    if (TRANSLATIONS[lang]) {
        console.log(`✅ Using cached translations for: ${lang}`);
        return TRANSLATIONS[lang];
    }

    try {
        const basePath = getCorrectBasePath();
        const response = await fetch(`${basePath}translations/${lang}.json`);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const translations = await response.json();
        TRANSLATIONS[lang] = translations;
        console.log(`✅ Loaded translations for: ${lang}`);
        return translations;
        
    } catch (error) {
        console.error(`❌ Failed to load translations for ${lang}:`, error);
        
        // Fallback to English if not already English
        if (lang !== 'en' && TRANSLATIONS['en']) {
            console.log('⚠️ Falling back to English translations');
            return TRANSLATIONS['en'];
        }
        
        return {};
    }
}

/**
 * Get translation by key (supports dot notation)
 * @param {string} key - Translation key (e.g., "nav.home")
 * @param {string} lang - Language code (optional, uses current language)
 */
function t(key, lang = currentLanguage) {
    const translations = TRANSLATIONS[lang] || TRANSLATIONS['en'] || {};
    const keys = key.split('.');
    let value = translations;
    
    for (const k of keys) {
        value = value?.[k];
        if (value === undefined) break;
    }
    
    // Fallback to English if translation not found
    if (value === undefined && lang !== 'en' && TRANSLATIONS['en']) {
        return t(key, 'en');
    }
    
    return value || key; // Return key if no translation found
}

/**
 * Apply translations to all elements with data-i18n attributes
 */
function applyTranslations() {
    console.log(`🌍 Applying translations for: ${currentLanguage}`);
    
    // Translate text content
    document.querySelectorAll('[data-i18n]').forEach(element => {
        const key = element.getAttribute('data-i18n');
        const translation = t(key);
        if (translation && translation !== key) {
            // Check if element has child nodes (like dropdown arrow)
            if (element.childNodes.length > 1 || (element.childNodes.length === 1 && element.childNodes[0].nodeType !== Node.TEXT_NODE)) {
                // Preserve child elements, only update first text node
                if (element.firstChild && element.firstChild.nodeType === Node.TEXT_NODE) {
                    element.firstChild.textContent = translation;
                } else {
                    // Insert text node before other children
                    element.insertBefore(document.createTextNode(translation), element.firstChild);
                }
            } else {
                // Simple case: just update text content
                element.textContent = translation;
            }
        }
    });
    
    // Translate placeholder attributes
    document.querySelectorAll('[data-i18n-placeholder]').forEach(element => {
        const key = element.getAttribute('data-i18n-placeholder');
        const translation = t(key);
        if (translation && translation !== key) {
            element.placeholder = translation;
        }
    });
    
    // Translate title attributes
    document.querySelectorAll('[data-i18n-title]').forEach(element => {
        const key = element.getAttribute('data-i18n-title');
        const translation = t(key);
        if (translation && translation !== key) {
            element.title = translation;
        }
    });
    
    // Translate alt attributes
    document.querySelectorAll('[data-i18n-alt]').forEach(element => {
        const key = element.getAttribute('data-i18n-alt');
        const translation = t(key);
        if (translation && translation !== key) {
            element.alt = translation;
        }
    });
    
    console.log('✅ Translations applied');
}

/**
 * Change language and reload the page
 * @param {string} lang - Language code to switch to
 */
function changeLanguage(lang) {
    console.log(`🔄 Changing language to: ${lang}`);
    
    // Save language preference
    localStorage.setItem('dcf_preferred_language', lang);
    
    // Force page reload to ensure all content (static + dynamic) loads in new language
    location.reload();
}

/**
 * Initialize language switcher dropdown
 */
function initializeLanguageSwitcher() {
    // Add CSS for language switcher if not already added
    if (!document.querySelector('#language-switcher-css')) {
        addLanguageSwitcherCSS();
    }
    
    const switchers = document.querySelectorAll('.language-switcher');
    const languages = {
        'en': 'EN',
        'it': 'IT',
        'es': 'ES',
        'hu': 'HU'
    };
    
    switchers.forEach(switcher => {
        // Clear existing content
        switcher.innerHTML = '';
        
        // Create dropdown button
        const dropdownBtn = document.createElement('button');
        dropdownBtn.className = 'lang-dropdown-btn';
        dropdownBtn.innerHTML = `${languages[currentLanguage]} `;
        dropdownBtn.setAttribute('aria-label', 'Select language');
        
        // Create dropdown menu
        const dropdownMenu = document.createElement('div');
        dropdownMenu.className = 'lang-dropdown-menu';
        
        // Add language options
        Object.entries(languages).forEach(([code, label]) => {
            if (code !== currentLanguage) {
                const option = document.createElement('button');
                option.className = 'lang-option';
                option.textContent = label;
                option.setAttribute('data-lang', code);
                option.onclick = () => {
                    changeLanguage(code);
                    closeLanguageDropdown();
                };
                dropdownMenu.appendChild(option);
            }
        });
        
        // Add to switcher
        switcher.appendChild(dropdownBtn);
        switcher.appendChild(dropdownMenu);
        
        // Toggle dropdown on button click
        dropdownBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            toggleLanguageDropdown(switcher);
        });
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', closeAllLanguageDropdowns);
}

function addLanguageSwitcherCSS() {
    const style = document.createElement('style');
    style.id = 'language-switcher-css';
    style.textContent = `
        .language-switcher {
            position: relative;
            display: inline-block;
        }
        
        .lang-dropdown-btn {
            background: transparent;
            border: 1px solid #e5e5e5;
            border-radius: 6px;
            padding: 0.5rem 1rem;
            font-size: 0.9rem;
            font-weight: 500;
            color: #333;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.2s ease;
            min-width: 60px;
            justify-content: center;
        }
        
        .lang-dropdown-btn:hover {
            border-color: #333;
            background: #f8f9fa;
        }
        
        .lang-dropdown-btn.active {
            border-color: #333;
            background: #f8f9fa;
        }
        
        .dropdown-arrow {
            font-size: 0.7em;
            transition: transform 0.2s ease;
        }
        
        .lang-dropdown-btn.active .dropdown-arrow {
            transform: rotate(180deg);
        }
        
        .lang-dropdown-menu {
            position: absolute;
            top: 100%;
            right: 0;
            background: white;
            border: 1px solid #e5e5e5;
            border-radius: 6px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            width: 100%;
            z-index: 1000;
            margin-top: 4px;
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.2s ease;
        }
        
        .lang-dropdown-menu.active {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }
        
        .lang-option {
            width: 100%;
            padding: 0.75rem 1rem;
            border: none;
            background: transparent;
            text-align: left;
            font-size: 0.9rem;
            color: #333;
            cursor: pointer;
            transition: background 0.2s ease;
        }
        
        .lang-option:hover {
            background: #f8f9fa;
        }
        
        .lang-option:first-child {
            border-radius: 6px 6px 0 0;
        }
        
        .lang-option:last-child {
            border-radius: 0 0 6px 6px;
        }
        
        /* Mobile responsive */
        @media (max-width: 768px) {
            .language-switcher {
                margin-left: 1rem;
            }
            
            .lang-dropdown-btn {
                padding: 0.4rem 0.8rem;
                font-size: 0.85rem;
                min-width: 50px;
            }
        }
    `;
    document.head.appendChild(style);
}

/**
 * Initialize mobile language switcher
 */
function initializeMobileLanguageSwitcher() {
    const mobileSwitcher = document.querySelector('.language-switcher-mobile');
    if (!mobileSwitcher) return;
    
    const languages = {
        'en': 'EN',
        'it': 'IT',
        'es': 'ES',
        'hu': 'HU'
    };
    
    // Create mobile language buttons (simpler for mobile)
    mobileSwitcher.innerHTML = Object.entries(languages).map(([code, label]) => 
        `<button class="mobile-lang-btn ${code === currentLanguage ? 'active' : ''}" 
                 data-lang="${code}" 
                 onclick="changeLanguage('${code}')">${label}</button>`
    ).join('');
}

/**
 * Toggle language dropdown visibility
 */
function toggleLanguageDropdown(switcher) {
    const menu = switcher.querySelector('.lang-dropdown-menu');
    const btn = switcher.querySelector('.lang-dropdown-btn');
    const isOpen = menu.classList.contains('active');
    
    // Close all other dropdowns first
    closeAllLanguageDropdowns();
    
    if (!isOpen) {
        menu.classList.add('active');
        btn.classList.add('active');
    }
}

/**
 * Close language dropdown
 */
function closeLanguageDropdown() {
    const menus = document.querySelectorAll('.lang-dropdown-menu');
    const btns = document.querySelectorAll('.lang-dropdown-btn');
    menus.forEach(menu => menu.classList.remove('active'));
    btns.forEach(btn => btn.classList.remove('active'));
}

/**
 * Close all language dropdowns
 */
function closeAllLanguageDropdowns() {
    const menus = document.querySelectorAll('.lang-dropdown-menu');
    const btns = document.querySelectorAll('.lang-dropdown-btn');
    menus.forEach(menu => menu.classList.remove('active'));
    btns.forEach(btn => btn.classList.remove('active'));
}

/**
 * Update simple language buttons UI
 */
function updateLanguageButtonsUI() {
    const buttons = document.querySelectorAll('.lang-btn');
    buttons.forEach(btn => {
        btn.classList.remove('active');
        if (btn.textContent.toLowerCase() === currentLanguage) {
            btn.classList.add('active');
        }
    });
}

/**
 * Update language switcher UI
 */
function updateLanguageSwitcherUI() {
    const languages = {
        'en': 'EN',
        'it': 'IT',
        'es': 'ES',
        'hu': 'HU'
    };
    
    // Update dropdown button text
    document.querySelectorAll('.lang-dropdown-btn').forEach(btn => {
        btn.innerHTML = `${languages[currentLanguage]} `;
    });
}

/**
 * Detect browser language and return supported language code
 */


/**
 * Add share bar CSS to page
 */
function addShareBarCSS() {
    if (document.querySelector('#shareBarCSS')) return;
    
    const style = document.createElement('style');
    style.id = 'shareBarCSS';
    style.textContent = `
        .share-sidebar {
            position: fixed;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            display: flex;
            flex-direction: column;
            gap: 12px;
            z-index: 90;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .share-sidebar.visible {
            opacity: 1;
        }

        .share-sidebar .share-btn {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            text-decoration: none;
            color: #666;
        }

        .share-sidebar .share-btn:hover {
            transform: scale(1.1);
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        }

        .share-sidebar .share-btn svg {
            width: 20px;
            height: 20px;
            fill: currentColor;
        }

        .share-sidebar .share-twitter:hover { background: #1DA1F2; color: white; }
        .share-sidebar .share-facebook:hover { background: #1877F2; color: white; }
        .share-sidebar .share-linkedin:hover { background: #0A66C2; color: white; }
        .share-sidebar .share-reddit:hover { background: #FF4500; color: white; }
        .share-sidebar .share-whatsapp:hover { background: #25D366; color: white; }
        .share-sidebar .share-email:hover { background: #EA4335; color: white; }
        .share-sidebar .share-copy:hover { background: #333; color: white; }

        @media (max-width: 1024px) {
            .share-sidebar {
                display: none;
            }
        }
    `;
    document.head.appendChild(style);
}

function detectBrowserLanguage() {
    const browserLang = navigator.language || navigator.userLanguage;
    const langCode = browserLang.split('-')[0].toLowerCase();
    
    // Check if detected language is supported
    const supportedLanguages = ['en', 'it', 'es', 'hu'];
    if (supportedLanguages.includes(langCode)) {
        console.log(`🌍 Detected browser language: ${langCode}`);
        return langCode;
    }
    
    console.log(`🌍 Browser language ${langCode} not supported, defaulting to English`);
    return 'en';
}

/**
 * Initialize translation system
 */
async function initializeTranslations() {
    console.log('🚀 Initializing translation system...');
    
    // Determine which language to use
    let savedLanguage = localStorage.getItem('dcf_preferred_language');
    
    if (!savedLanguage) {
        // First visit - detect browser language
        savedLanguage = detectBrowserLanguage();
        localStorage.setItem('dcf_preferred_language', savedLanguage);
    }
    
    currentLanguage = savedLanguage;
    console.log(`📍 Using language: ${currentLanguage}`);
    
    // Initialize simple language buttons on launch pages
    if (isLaunchPage()) {
        updateLanguageButtonsUI();
    }
    
    // Only load and apply translations on launch pages
    if (!isLaunchPage()) {
        console.log('ℹ️ Skipping translation loading - not a launch page');
        return;
    }
    
    // Load translations
    await loadTranslations(currentLanguage);
    
    // Apply translations to page
    applyTranslations();
    
    console.log('✅ Translation system initialized');
}

// =============================================================================
// END TRANSLATION SYSTEM
// =============================================================================

// =============================================================================
// 2. USER INTERFACE MANAGEMENT
// =============================================================================

function updateUserInterface() {
    console.log('🎨 Updating UI (logged out state)...');

showLoggedOutState();
createAndInjectNavigation();  // Use new dual navigation system
populateLogo();  // Use new logo generation system
handleResponsiveLogo();  // Enable responsive logo behavior
initializeMobileMenu();  // Initialize mobile menu system

// Initialize translations after navigation is built
initializeTranslations();
    
    initializeFooter();
    
    // Hide launch-specific elements after DOM is populated
    setTimeout(() => {
        hideLaunchPageElements();
    }, 100);
    
    console.log('✅ UI updated for logged-out state');
}

function showLoggedOutState() {
    console.log('👤 Showing logged-out UI state');
    
    const userMenu = document.querySelector('.user-menu');
    if (!userMenu) {
        console.log('❌ User menu container not found');
        return;
    }
    
    const basePath = window.getCorrectBasePath();
    
    // Check if we're on a launch page
    const onLaunchPage = isLaunchPage();
    
    if (onLaunchPage) {
        // Launch pages: No login or join buttons but ensure language switcher is present
        userMenu.innerHTML = '';
        
        // Create language switcher container
        const languageSwitcher = document.createElement('div');
        languageSwitcher.className = 'language-switcher';
        userMenu.appendChild(languageSwitcher);
        
        // Initialize the language switcher
        initializeLanguageSwitcher();
        
        console.log('🚀 Launch page: Hidden login/join buttons, added language switcher');
    } else {
        // Member pages: Show both login and join buttons
        userMenu.innerHTML = `
            <a href="${basePath}auth/dcf_login_page.html" class="login-btn" style="color: #333; text-decoration: none; font-size: 0.9rem; padding: 0.5rem 1rem; border-radius: 6px;">Login</a>
            <a href="${basePath}auth/dcf_profile_signup.html" class="join-btn" style="background: #000; color: white; padding: 0.5rem 1.5rem; border: none; border-radius: 6px; font-size: 0.9rem; text-decoration: none; display: inline-block;">Join Us</a>
        `;
        console.log('👥 Member page: Showing login/join buttons');
    }
}

function hideLaunchPageElements() {
    // Only run on launch pages
    if (!isLaunchPage()) {
        console.log('ℹ️ Not a launch page, keeping all elements visible');
        return;
    }
    
    console.log('🚀 Launch page detected - hiding member/auth elements');
    
    // Hide "Join Us" buttons
    const joinButtons = document.querySelectorAll('a[href*="signup"], a[href*="join"], .join-btn, .signup-btn, button.join-btn');
    joinButtons.forEach(btn => {
        const btnText = btn.textContent.toLowerCase();
        if (btnText.includes('join') || 
            btnText.includes('sign up') ||
            btnText.includes('create account') ||
            btnText.includes('register')) {
            btn.style.display = 'none';
            console.log('🔒 Hiding join/signup button:', btn.textContent.trim());
        }
    });
    
    // Hide signup prompts and links
    const signupPrompts = document.querySelectorAll('p, div, span');
    signupPrompts.forEach(element => {
        const text = element.textContent.toLowerCase();
        if ((text.includes('new to dcf') || 
             text.includes('create an account') ||
             text.includes('sign up today') ||
             text.includes('join us today')) &&
            element.querySelector('a[href*="signup"], a[href*="join"]')) {
            element.style.display = 'none';
            console.log('🔒 Hiding signup prompt:', element.textContent.substring(0, 50) + '...');
        }
    });
    
    // Hide any remaining signup links not caught above
    const signupLinks = document.querySelectorAll('a[href*="dcf_profile_signup"], a[href*="signup"], a[href*="register"]');
    signupLinks.forEach(link => {
        // Don't hide if it's part of main navigation (already handled)
        if (!link.closest('.nav-menu')) {
            const linkText = link.textContent.toLowerCase();
            if (linkText.includes('create') || linkText.includes('sign') || linkText.includes('join')) {
                link.style.display = 'none';
                console.log('🔒 Hiding signup link:', link.textContent.trim());
            }
        }
    });
    
    console.log('✅ Launch page elements hidden');
}

// =============================================================================
// LOGO GENERATION SYSTEM
// =============================================================================

function generateLogo() {
    const isLaunch = isLaunchPage();
    const isMobile = window.innerWidth < 1024;
    
    // Determine which text to show
    let logoText;
    if (isMobile) {
        logoText = LOGO_CONFIG.text.abbrev;
    } else {
        logoText = isLaunch ? LOGO_CONFIG.text.full : LOGO_CONFIG.text.short;
    }
    
    const basePath = window.getCorrectBasePath();
    
    console.log('🏷️ Generating logo:', { 
        pageType: isLaunch ? 'LAUNCH' : 'MEMBER',
        isMobile,
        text: logoText 
    });
    
    // Create logo container
    const logoLink = document.createElement('a');
    logoLink.href = basePath + LOGO_CONFIG.link;
    logoLink.className = 'logo';
    logoLink.style.cssText = `
        display: flex;
        align-items: center;
        text-decoration: none;
        color: #333;
        font-weight: 600;
        font-size: 1rem;
    `;
    
    // Create logo icon
    if (LOGO_CONFIG.icon.type === 'circle') {
        const iconDiv = document.createElement('div');
        iconDiv.className = 'logo-icon';
        iconDiv.style.cssText = `
            width: ${LOGO_CONFIG.icon.size};
            height: ${LOGO_CONFIG.icon.size};
            background: ${LOGO_CONFIG.icon.color};
            border-radius: 50%;
            margin-right: 8px;
            flex-shrink: 0;
        `;
        logoLink.appendChild(iconDiv);
    } else if (LOGO_CONFIG.icon.type === 'image' && LOGO_CONFIG.icon.imageUrl) {
        const iconImg = document.createElement('img');
        iconImg.src = basePath + LOGO_CONFIG.icon.imageUrl;
        iconImg.className = 'logo-icon';
        iconImg.style.cssText = `
            width: ${LOGO_CONFIG.icon.size};
            height: ${LOGO_CONFIG.icon.size};
            margin-right: 8px;
            flex-shrink: 0;
        `;
        iconImg.alt = 'Logo';
        logoLink.appendChild(iconImg);
    }
    
    // Create logo text
    const textSpan = document.createElement('span');
    textSpan.className = 'logo-text';
    textSpan.textContent = logoText;
    textSpan.style.cssText = 'white-space: nowrap;';
    logoLink.appendChild(textSpan);
    
    console.log('✅ Logo generated');
    return logoLink;
}

function populateLogo() {
    // Find logo container in navigation - try multiple selectors
    let logoContainer = document.querySelector('.logo-container') || 
                       document.querySelector('.nav-container > .logo') ||
                       document.querySelector('.nav-container');
    
    if (!logoContainer) {
        console.log('⚠️ Logo container not found');
        return;
    }
    
    console.log('🏷️ Populating logo...');
    
    // If we found nav-container, we'll prepend the logo to it
    if (logoContainer.classList.contains('nav-container')) {
        // Check if there's already a logo
        const existingLogo = logoContainer.querySelector('.logo');
        if (existingLogo) {
            existingLogo.remove();
        }
        
        // Generate and insert new logo at the beginning
        const newLogo = generateLogo();
        logoContainer.insertBefore(newLogo, logoContainer.firstChild);
    } else if (logoContainer.classList.contains('logo')) {
        // The container itself is the logo link - replace it entirely
        const newLogo = generateLogo();
        logoContainer.parentNode.replaceChild(newLogo, logoContainer);
    } else if (logoContainer.classList.contains('logo-container')) {
        // It's a dedicated logo container - replace content
        logoContainer.innerHTML = '';
        const newLogo = generateLogo();
        logoContainer.appendChild(newLogo);
    }
    
    console.log('✅ Logo populated');
}

function handleResponsiveLogo() {
    console.log('📱 Setting up responsive logo handling...');
    
    // Update logo text based on screen width
    function updateLogoResponsive() {
        const logoText = document.querySelector('.logo-text');
        if (!logoText) return;
        
        const isLaunch = isLaunchPage();
        const width = window.innerWidth;
        
        if (width < 768) {
            // Mobile: show abbreviation
            logoText.textContent = LOGO_CONFIG.text.abbrev;
        } else {
            // Desktop: show full or short based on page type
            logoText.textContent = isLaunch ? 
                LOGO_CONFIG.text.full : 
                LOGO_CONFIG.text.short;
        }
        
        console.log('📱 Logo text updated:', logoText.textContent);
    }
    
    // Update on load
    updateLogoResponsive();
    
    // Debounce resize events for performance
    let resizeTimeout;
    window.addEventListener('resize', () => {
        clearTimeout(resizeTimeout);
        resizeTimeout = setTimeout(updateLogoResponsive, 250);
    });
    
    console.log('✅ Responsive logo handling enabled');
}

// Keep old function for backward compatibility
function updateLogoText() {
    console.log('🏷️ Updating logo text (legacy call - using populateLogo instead)...');
    populateLogo();
}

// =============================================================================
// 3. MODAL SYSTEM
// =============================================================================

function showAlert(message, type = 'info', title = null) {
    return new Promise((resolve) => {
        removeExistingAlert();
        
        const alertDiv = document.createElement('div');
        alertDiv.className = 'dcf-alert';
        alertDiv.setAttribute('data-type', type);
        
        const iconMap = {
            'info': '💡',
            'success': '✅', 
            'warning': '⚠️',
            'error': '❌',
            'question': '❓'
        };
        
        const titleMap = {
            'info': 'Information',
            'success': 'Success',
            'warning': 'Warning', 
            'error': 'Error',
            'question': 'Confirm'
        };
        
        alertDiv.innerHTML = `
            <div class="dcf-alert-overlay" onclick="closeAlert()"></div>
            <div class="dcf-alert-content">
                <div class="dcf-alert-header">
                    <span class="dcf-alert-icon">${iconMap[type]}</span>
                    <h3 class="dcf-alert-title">${title || titleMap[type]}</h3>
                </div>
                <div class="dcf-alert-message">${message}</div>
                <div class="dcf-alert-actions">
                    <button class="dcf-alert-btn dcf-alert-btn-primary" onclick="closeAlert(true)">OK</button>
                </div>
            </div>
        `;
        
        addAlertCSS();
        document.body.appendChild(alertDiv);
        setTimeout(() => alertDiv.classList.add('active'), 10);
        
        window.currentAlertResolve = resolve;
    });
}

function showConfirm(message, title = 'Confirm') {
    return new Promise((resolve) => {
        removeExistingAlert();
        
        const alertDiv = document.createElement('div');
        alertDiv.className = 'dcf-alert';
        alertDiv.setAttribute('data-type', 'question');
        
        alertDiv.innerHTML = `
            <div class="dcf-alert-overlay" onclick="closeAlert(false)"></div>
            <div class="dcf-alert-content">
                <div class="dcf-alert-header">
                    <span class="dcf-alert-icon">❓</span>
                    <h3 class="dcf-alert-title">${title}</h3>
                </div>
                <div class="dcf-alert-message">${message}</div>
                <div class="dcf-alert-actions">
                    <button class="dcf-alert-btn dcf-alert-btn-secondary" onclick="closeAlert(false)">Cancel</button>
                    <button class="dcf-alert-btn dcf-alert-btn-primary" onclick="closeAlert(true)">Confirm</button>
                </div>
            </div>
        `;
        
        addAlertCSS();
        document.body.appendChild(alertDiv);
        setTimeout(() => alertDiv.classList.add('active'), 10);
        
        window.currentAlertResolve = resolve;
    });
}

function showPrompt(message, defaultValue = '', title = 'Input Required') {
    return new Promise((resolve) => {
        removeExistingAlert();
        
        const alertDiv = document.createElement('div');
        alertDiv.className = 'dcf-alert';
        alertDiv.setAttribute('data-type', 'question');
        
        alertDiv.innerHTML = `
            <div class="dcf-alert-overlay" onclick="closeAlert(null)"></div>
            <div class="dcf-alert-content">
                <div class="dcf-alert-header">
                    <span class="dcf-alert-icon">✏️</span>
                    <h3 class="dcf-alert-title">${title}</h3>
                </div>
                <div class="dcf-alert-message">${message}</div>
                <div class="dcf-alert-input">
                    <input type="text" class="dcf-prompt-input" value="${defaultValue}" placeholder="Enter text..." />
                </div>
                <div class="dcf-alert-actions">
                    <button class="dcf-alert-btn dcf-alert-btn-secondary" onclick="closeAlert(null)">Cancel</button>
                    <button class="dcf-alert-btn dcf-alert-btn-primary" onclick="closeAlertWithInput()">OK</button>
                </div>
            </div>
        `;
        
        addAlertCSS();
        document.body.appendChild(alertDiv);
        setTimeout(() => {
            alertDiv.classList.add('active');
            const input = alertDiv.querySelector('.dcf-prompt-input');
            if (input) {
                input.focus();
                input.select();
                input.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter') closeAlertWithInput();
                    if (e.key === 'Escape') closeAlert(null);
                });
            }
        }, 10);
        
        window.currentAlertResolve = resolve;
    });
}

function closeAlert(result = false) {
    const alert = document.querySelector('.dcf-alert');
    if (alert) {
        alert.classList.remove('active');
        setTimeout(() => {
            if (alert.parentNode) alert.parentNode.removeChild(alert);
        }, 300);
    }
    
    if (window.currentAlertResolve) {
        window.currentAlertResolve(result);
        window.currentAlertResolve = null;
    }
}

function closeAlertWithInput() {
    const input = document.querySelector('.dcf-prompt-input');
    const value = input ? input.value : null;
    closeAlert(value);
}

function removeExistingAlert() {
    const existingAlert = document.querySelector('.dcf-alert');
    if (existingAlert) {
        existingAlert.remove();
    }
}

function addAlertCSS() {
    if (!document.querySelector('#dcf-alert-css')) {
        const style = document.createElement('style');
        style.id = 'dcf-alert-css';
        style.textContent = `
            .dcf-alert {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0, 0, 0, 0.5);
                z-index: 10000;
                display: flex;
                align-items: center;
                justify-content: center;
                opacity: 0;
                visibility: hidden;
                transition: all 0.3s ease;
            }
            
            .dcf-alert.active {
                opacity: 1;
                visibility: visible;
            }
            
            .dcf-alert-overlay {
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                cursor: pointer;
            }
            
            .dcf-alert-content {
                background: white;
                border-radius: 12px;
                padding: 0;
                max-width: 450px;
                width: 90%;
                position: relative;
                z-index: 1;
                box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
                transform: scale(0.9);
                transition: transform 0.3s ease;
                overflow: hidden;
            }
            
            .dcf-alert.active .dcf-alert-content {
                transform: scale(1);
            }
            
            .dcf-alert-header {
                display: flex;
                align-items: center;
                gap: 1rem;
                padding: 1.5rem 1.5rem 1rem 1.5rem;
                border-bottom: 1px solid #f0f0f0;
            }
            
            .dcf-alert-icon {
                font-size: 1.5rem;
                flex-shrink: 0;
            }
            
            .dcf-alert-title {
                margin: 0;
                font-size: 1.2rem;
                font-weight: 600;
                color: #333;
            }
            
            .dcf-alert-message {
                padding: 1.5rem;
                color: #666;
                line-height: 1.6;
                font-size: 0.95rem;
            }
            
            .dcf-alert-input {
                padding: 0 1.5rem;
            }
            
            .dcf-prompt-input {
                width: 100%;
                padding: 0.75rem;
                border: 2px solid #e5e5e5;
                border-radius: 8px;
                font-size: 0.95rem;
                transition: border-color 0.3s ease;
                outline: none;
            }
            
            .dcf-prompt-input:focus {
                border-color: #000;
            }
            
            .dcf-alert-actions {
                padding: 1rem 1.5rem 1.5rem 1.5rem;
                display: flex;
                gap: 0.75rem;
                justify-content: flex-end;
                background: #fafafa;
            }
            
            .dcf-alert-btn {
                padding: 0.6rem 1.5rem;
                border: none;
                border-radius: 8px;
                font-size: 0.9rem;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.3s ease;
                min-width: 80px;
            }
            
            .dcf-alert-btn-primary {
                background: #000;
                color: white;
            }
            
            .dcf-alert-btn-primary:hover {
                background: #333;
                transform: translateY(-1px);
            }
            
            .dcf-alert-btn-secondary {
                background: transparent;
                color: #666;
                border: 2px solid #e5e5e5;
            }
            
            .dcf-alert-btn-secondary:hover {
                color: #333;
                border-color: #333;
                transform: translateY(-1px);
            }
        `;
        document.head.appendChild(style);
    }
}

// =============================================================================
// 4. FOOTER SYSTEM
// =============================================================================

// Footer Configuration - Data-driven for easy maintenance
const FOOTER_CONFIG = {
    sections: [
        {
            title: 'Quick Links',
            titleKey: 'footer_quick_links',
            type: 'links',
            items: [
                { text: 'Home', id: 'home', href: 'index.html' },
                { text: 'Values', id: 'values', href: 'public/dcf_values.html' },
                { text: 'Initiatives', id: 'initiatives', href: 'initiatives/index.html' },
                { text: 'Blog', id: 'blog', href: 'blog/index.html' },
                { text: 'Contact', id: 'contact', href: 'public/dcf_contact.html' }
            ]
        },
        {
            title: 'Stay Updated',
            titleKey: 'footer_stay_updated',
            type: 'newsletter',
            description: 'Subscribe to our newsletter for the latest updates and insights.',
            descriptionKey: 'footer_newsletter_desc',
            placeholder: 'Your email address',
            placeholderKey: 'footer_email_placeholder',
            buttonText: 'Subscribe',
            buttonKey: 'footer_subscribe'
        },
        {
            title: 'Support Our Mission',
            titleKey: 'footer_support_mission',
            type: 'donation',
            description: 'Help us continue our work in fostering democratic innovation and community development.',
            descriptionKey: 'footer_donation_desc',
            buttonText: 'Make a Donation',
            buttonKey: 'footer_donate_button',
            buttonLink: 'members/dcf_donate.html'
        },
        {
            title: 'Connect With Us',
            titleKey: 'footer_connect',
            type: 'social',
            links: [
                {
                    name: 'Twitter',
                    title: 'Share on Twitter',
                    titleKey: 'footer_share_twitter',
                    icon: '<svg viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>',
                    action: 'twitter'
                },
                {
                    name: 'Facebook',
                    title: 'Share on Facebook',
                    titleKey: 'footer_share_facebook', 
                    icon: '<svg viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>',
                    action: 'facebook'
                },
                {
                    name: 'LinkedIn',
                    title: 'Share on LinkedIn',
                    titleKey: 'footer_share_linkedin',
                    icon: '<svg viewBox="0 0 24 24"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>',
                    action: 'linkedin'
                },
                {
                    name: 'Reddit',
                    title: 'Share on Reddit',
                    titleKey: 'footer_share_reddit',
                    icon: '<svg viewBox="0 0 24 24"><path d="M12 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0zm5.01 4.744c.688 0 1.25.561 1.25 1.249a1.25 1.25 0 0 1-2.498.056l-2.597-.547-.8 3.747c1.824.07 3.48.632 4.674 1.488.308-.309.73-.491 1.207-.491.968 0 1.754.786 1.754 1.754 0 .716-.435 1.333-1.01 1.614a3.111 3.111 0 0 1 .042.52c0 2.694-3.13 4.87-7.004 4.87-3.874 0-7.004-2.176-7.004-4.87 0-.183.015-.366.043-.534A1.748 1.748 0 0 1 4.028 12c0-.968.786-1.754 1.754-1.754.463 0 .898.196 1.207.49 1.207-.883 2.878-1.43 4.744-1.487l.885-4.182a.342.342 0 0 1 .14-.197.35.35 0 0 1 .238-.042l2.906.617a1.214 1.214 0 0 1 1.108-.701zM9.25 12C8.561 12 8 12.562 8 13.25c0 .687.561 1.248 1.25 1.248.687 0 1.248-.561 1.248-1.249 0-.688-.561-1.249-1.249-1.249zm5.5 0c-.687 0-1.248.561-1.248 1.25 0 .687.561 1.248 1.249 1.248.688 0 1.249-.561 1.249-1.249 0-.687-.562-1.249-1.25-1.249zm-5.466 3.99a.327.327 0 0 0-.231.094.33.33 0 0 0 0 .463c.842.842 2.484.913 2.961.913.477 0 2.105-.056 2.961-.913a.361.361 0 0 0 .029-.463.33.33 0 0 0-.464 0c-.547.533-1.684.73-2.512.73-.828 0-1.979-.196-2.512-.73a.326.326 0 0 0-.232-.095z"/></svg>',
                    action: 'reddit'
                },
                {
                    name: 'WhatsApp',
                    title: 'Share on WhatsApp',
                    titleKey: 'footer_share_whatsapp',
                    icon: '<svg viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>',
                    action: 'whatsapp'
                },
                {
                    name: 'Email',
                    title: 'Share via Email',
                    titleKey: 'footer_share_email',
                    icon: '<svg viewBox="0 0 24 24"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>',
                    action: 'email'
                },
                {
                    name: 'Copy Link',
                    title: 'Copy Link',
                    titleKey: 'footer_copy_link',
                    icon: '<svg viewBox="0 0 24 24"><path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/></svg>',
                    action: 'copy'
                }
            ]
        }
    ],
    bottom: {
        copyright: '© 2024 Domus Communis Foundation Hungary. All rights reserved.',
        copyrightKey: 'footer_copyright',
        legal: [
            { text: 'Privacy Policy', textKey: 'footer_privacy', href: '#' },
            { text: 'Terms of Service', textKey: 'footer_terms', href: '#' }
        ]
    }
};

function initializeFooter() {
    console.log('🦶 Initializing DCF footer system...');
    
    // Only show footer on launch pages
    if (!isLaunchPage()) {
        console.log('📝 Not a launch page - skipping footer');
        return;
    }
    
    // Check if footer already exists
    if (document.querySelector('.dcf-footer')) {
        console.log('🦶 Footer already exists');
        return;
    }
    
    // Create footer HTML
    const footerHTML = generateFooterHTML();
    
    // Insert footer before closing body tag
    document.body.insertAdjacentHTML('beforeend', footerHTML);
    
    // Add footer CSS if not already added
    if (!document.querySelector('#dcf-footer-styles')) {
        injectFooterCSS();
    }
    
    // Initialize footer functionality
    initializeFooterHandlers();
    
    console.log('✅ DCF footer initialized');
}

function generateFooterHTML() {
    const basePath = window.getCorrectBasePath();
    
    let sectionsHTML = '';
    
    // Generate each footer section based on config
    FOOTER_CONFIG.sections.forEach(section => {
        sectionsHTML += '<div class="footer-section">';
        sectionsHTML += `<h4 class="footer-title" ${section.titleKey ? `data-i18n="${section.titleKey}"` : ''}>${section.title}</h4>`;
        
        switch(section.type) {
            case 'links':
                sectionsHTML += '<ul class="footer-links">';
                section.items.forEach(item => {
                    sectionsHTML += `<li><a href="${basePath}${item.href}" ${item.id ? `data-i18n="${item.id}"` : ''}>${item.text}</a></li>`;
                });
                sectionsHTML += '</ul>';
                break;
                
            case 'newsletter':
                sectionsHTML += `
                    <p class="footer-text" ${section.descriptionKey ? `data-i18n="${section.descriptionKey}"` : ''}>${section.description}</p>
                    <form class="newsletter-form" id="footerNewsletterForm">
                        <input type="email" placeholder="${section.placeholder}" ${section.placeholderKey ? `data-i18n-placeholder="${section.placeholderKey}"` : ''} class="newsletter-input" required>
                        <button type="submit" class="newsletter-btn" ${section.buttonKey ? `data-i18n="${section.buttonKey}"` : ''}>${section.buttonText}</button>
                    </form>
                `;
                break;
                
            case 'donation':
                sectionsHTML += `
                    <p class="footer-text" ${section.descriptionKey ? `data-i18n="${section.descriptionKey}"` : ''}>${section.description}</p>
                    <a href="${basePath}${section.buttonLink}" class="donate-btn" ${section.buttonKey ? `data-i18n="${section.buttonKey}"` : ''}>${section.buttonText}</a>
                `;
                break;
                
            case 'social':
                sectionsHTML += '<div class="social-links">';
                section.links.forEach(link => {
                    sectionsHTML += `
                        <a href="#" class="social-link" title="${link.title}" ${link.titleKey ? `data-i18n-title="${link.titleKey}"` : ''} data-action="${link.action}">
                            ${link.icon}
                        </a>
                    `;
                });
                sectionsHTML += '</div>';
                break;
        }
        
        sectionsHTML += '</div>';
    });
    
    // Generate footer bottom with legal links
    let legalHTML = '';
    FOOTER_CONFIG.bottom.legal.forEach((link, index) => {
        if (index > 0) legalHTML += '<span class="separator">•</span>';
        legalHTML += `<a href="${link.href}" ${link.textKey ? `data-i18n="${link.textKey}"` : ''}>${link.text}</a>`;
    });
    
    return `
        <footer class="dcf-footer">
            <div class="footer-container">
                <div class="footer-content">
                    ${sectionsHTML}
                </div>
                <div class="footer-bottom">
                    <p ${FOOTER_CONFIG.bottom.copyrightKey ? `data-i18n="${FOOTER_CONFIG.bottom.copyrightKey}"` : ''}>${FOOTER_CONFIG.bottom.copyright}</p>
                    <div class="footer-legal">
                        ${legalHTML}
                    </div>
                </div>
            </div>
        </footer>
    `;
}

function injectFooterCSS() {
    const style = document.createElement('style');
    style.id = 'dcf-footer-styles';
    style.textContent = `
        .dcf-footer {
            background: #1a1a1a;
            color: #e0e0e0;
            padding: 4rem 0 2rem;
            margin-top: 5rem;
        }

        .footer-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 2rem;
        }

        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(min(100%, 250px), 1fr));
            gap: 3rem;
            margin-bottom: 3rem;
        }

        .footer-section {
            min-width: 0;
        }

        .footer-title {
            font-size: 1.1rem;
            font-weight: 600;
            margin-bottom: 1.5rem;
            color: white;
        }

        .footer-text {
            font-size: 0.9rem;
            line-height: 1.6;
            margin-bottom: 1rem;
            color: #b0b0b0;
        }

        .footer-links {
            list-style: none;
            padding: 0;
        }

        .footer-links li {
            margin-bottom: 0.75rem;
        }

        .footer-links a {
            color: #b0b0b0;
            text-decoration: none;
            font-size: 0.9rem;
            transition: color 0.3s ease;
        }

        .footer-links a:hover {
            color: white;
        }

        /* Newsletter Form */
        .newsletter-form {
            display: flex;
            flex-direction: column;
            gap: 0.75rem;
        }

        .newsletter-input {
            padding: 0.75rem 1rem;
            border: 1px solid #333;
            border-radius: 8px;
            background: #2a2a2a;
            color: white;
            font-size: 0.9rem;
        }

        .newsletter-input::placeholder {
            color: #666;
        }

        .newsletter-input:focus {
            outline: none;
            border-color: #555;
            background: #333;
        }

        .newsletter-btn {
            padding: 0.75rem 1.5rem;
            background: #333;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 0.9rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .newsletter-btn:hover {
            background: #444;
            transform: translateY(-1px);
        }

        /* Donation Button */
        .donate-btn {
            display: inline-block;
            padding: 0.75rem 2rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 500;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            margin-top: 0.5rem;
        }

        .donate-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(102, 126, 234, 0.4);
        }

        /* Social Links */
        .social-links {
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
        }

        .social-link {
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #2a2a2a;
            border-radius: 50%;
            transition: all 0.3s ease;
            color: #b0b0b0;
        }

        .social-link:hover {
            background: #333;
            transform: translateY(-2px);
            color: white;
        }

        .social-link svg {
            width: 20px;
            height: 20px;
            fill: currentColor;
        }

        /* Footer Bottom */
        .footer-bottom {
            padding-top: 2rem;
            border-top: 1px solid #333;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .footer-bottom p {
            font-size: 0.85rem;
            color: #808080;
            margin: 0;
        }

        .footer-legal {
            display: flex;
            gap: 1rem;
            align-items: center;
        }

        .footer-legal a {
            color: #808080;
            text-decoration: none;
            font-size: 0.85rem;
            transition: color 0.3s ease;
        }

        .footer-legal a:hover {
            color: #b0b0b0;
        }

        .footer-legal .separator {
            color: #555;
        }

        /* Mobile Responsiveness */
        @media (max-width: 768px) {
            .dcf-footer {
                padding: 3rem 0 1.5rem;
                margin-top: 3rem;
            }

            .footer-content {
                grid-template-columns: 1fr;
                gap: 2rem;
            }

            .footer-bottom {
                flex-direction: column;
                text-align: center;
            }

            .footer-legal {
                justify-content: center;
            }

            .social-links {
                justify-content: center;
            }
        }

        @media (max-width: 600px) {
            .footer-container {
                padding: 0 1rem;
            }

            .footer-title {
                font-size: 1rem;
            }

            .newsletter-form {
                margin-top: 0.5rem;
            }

            .donate-btn {
                width: 100%;
                text-align: center;
            }
        }

        /* Copy success animation */
        @keyframes slideUp {
            from {
                transform: translateX(-50%) translateY(100%);
                opacity: 0;
            }
            to {
                transform: translateX(-50%) translateY(0);
                opacity: 1;
            }
        }
    `;
    document.head.appendChild(style);
}

function initializeFooterHandlers() {
    // Newsletter form handler
    const newsletterForm = document.getElementById('footerNewsletterForm');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = this.querySelector('input[type="email"]').value;
            
            // Use the existing showAlert function from dcf-ui
            if (window.showAlert) {
                window.showAlert(`Thank you for subscribing with email: ${email}`, 'success', 'Subscribed!');
            } else {
                alert(`Thank you for subscribing with email: ${email}`);
            }
            
            this.reset();
        });
    }
    
    // Social share handlers
    const socialLinks = document.querySelectorAll('.dcf-footer .social-link');
    socialLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const action = this.dataset.action;
            handleSocialShare(action);
        });
    });
}

function handleSocialShare(action) {
    const url = window.location.href;
    const title = 'Domus Communis Foundation Hungary';
    const text = 'Check out Domus Communis Foundation Hungary';
    
    switch(action) {
        case 'twitter':
            window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`, '_blank', 'width=600,height=400');
            break;
        case 'facebook':
            window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`, '_blank', 'width=600,height=400');
            break;
        case 'linkedin':
            window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}&title=${encodeURIComponent(title)}`, '_blank', 'width=600,height=400');
            break;
        case 'reddit':
            window.open(`https://reddit.com/submit?url=${encodeURIComponent(url)}&title=${encodeURIComponent(title)}`, '_blank', 'width=600,height=400');
            break;
        case 'whatsapp':
            window.open(`https://wa.me/?text=${encodeURIComponent(text + ' ' + url)}`, '_blank');
            break;
        case 'email':
            const subject = `Check out: ${title}`;
            const body = `I thought you might find this interesting:\n\n${title}\n\n${url}`;
            window.location.href = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
            break;
        case 'copy':
            // Copy URL to clipboard
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(url).then(() => {
                    // Show success message
                    if (window.showAlert) {
                        window.showAlert('Link copied to clipboard!', 'success', 'Success');
                    } else {
                        // Fallback: create temporary success message
                        const successMsg = document.createElement('div');
                        successMsg.textContent = 'Link copied to clipboard!';
                        successMsg.style.cssText = `
                            position: fixed;
                            bottom: 20px;
                            left: 50%;
                            transform: translateX(-50%);
                            background: #28a745;
                            color: white;
                            padding: 12px 24px;
                            border-radius: 4px;
                            z-index: 10000;
                            animation: slideUp 0.3s ease;
                        `;
                        document.body.appendChild(successMsg);
                        setTimeout(() => successMsg.remove(), 3000);
                    }
                }).catch(() => {
                    // Fallback for older browsers
                    const textArea = document.createElement('textarea');
                    textArea.value = url;
                    textArea.style.position = 'fixed';
                    textArea.style.opacity = '0';
                    document.body.appendChild(textArea);
                    textArea.select();
                    try {
                        document.execCommand('copy');
                        if (window.showAlert) {
                            window.showAlert('Link copied to clipboard!', 'success', 'Success');
                        }
                    } catch (err) {
                        if (window.showAlert) {
                            window.showAlert('Failed to copy link', 'error', 'Error');
                        }
                    }
                    document.body.removeChild(textArea);
                });
            } else {
                // Very old browser fallback
                const textArea = document.createElement('textarea');
                textArea.value = url;
                textArea.style.position = 'fixed';
                textArea.style.opacity = '0';
                document.body.appendChild(textArea);
                textArea.select();
                try {
                    document.execCommand('copy');
                    if (window.showAlert) {
                        window.showAlert('Link copied to clipboard!', 'success', 'Success');
                    }
                } catch (err) {
                    if (window.showAlert) {
                        window.showAlert('Failed to copy link', 'error', 'Error');
                    }
                }
                document.body.removeChild(textArea);
            }
            break;
    }
}

// =============================================================================
// 5. MOBILE MENU SYSTEM
// =============================================================================

function initializeMobileMenu() {
    console.log('📱 Initializing mobile menu system...');
    
    // Create mobile menu toggle button
    const navContainer = document.querySelector('.nav-container');
    if (!navContainer) {
        console.log('❌ Nav container not found for mobile menu');
        return;
    }
    
    // Check if mobile menu toggle already exists
    if (document.querySelector('.mobile-menu-toggle')) {
        console.log('📱 Mobile menu toggle already exists');
        return;
    }
    
    // Create the hamburger button
    const mobileToggle = document.createElement('button');
    mobileToggle.className = 'mobile-menu-toggle';
    mobileToggle.innerHTML = '☰';
    mobileToggle.setAttribute('aria-label', 'Toggle navigation menu');
    mobileToggle.style.cssText = `
        display: none;
        background: none;
        border: 2px solid #e5e5e5;
        border-radius: 8px;
        padding: 0.5rem 1rem;
        font-size: 1.5rem;
        cursor: pointer;
        color: #333;
        transition: all 0.3s ease;
        margin-left: auto;
        margin-right: 1rem;
    `;
    
    // Insert button between logo and user-menu
    const userMenu = navContainer.querySelector('.user-menu');
    if (userMenu) {
        navContainer.insertBefore(mobileToggle, userMenu);
    } else {
        navContainer.appendChild(mobileToggle);
    }
    
    // Add click handler
    mobileToggle.addEventListener('click', toggleMobileMenu);
    
    // Close menu when clicking outside
    document.addEventListener('click', (e) => {
        const navMenu = document.querySelector('.nav-menu');
        if (navMenu && navMenu.classList.contains('mobile-active')) {
            if (!e.target.closest('.nav-menu') && !e.target.closest('.mobile-menu-toggle')) {
                closeMobileMenu();
            }
        }
    });
    
    // Close menu when window resizes above 768px
    let resizeTimer;
    window.addEventListener('resize', () => {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(() => {
            if (window.innerWidth > 1024) {
                closeMobileMenu();
            }
        }, 250);
    });
    
    // Close menu when clicking nav links
    const navMenu = document.querySelector('.nav-menu');
    if (navMenu) {
        navMenu.addEventListener('click', (e) => {
            if (e.target.tagName === 'A' && window.innerWidth <= 1024) {
                // Small delay to allow navigation to start
                setTimeout(() => closeMobileMenu(), 100);
            }
        });
    }
    
    console.log('✅ Mobile menu system initialized');
}

function toggleMobileMenu() {
    const navMenu = document.querySelector('.nav-menu');
    const mobileToggle = document.querySelector('.mobile-menu-toggle');
    
    if (!navMenu || !mobileToggle) return;
    
    if (navMenu.classList.contains('mobile-active')) {
        closeMobileMenu();
    } else {
        openMobileMenu();
    }
}

function openMobileMenu() {
    const navMenu = document.querySelector('.nav-menu');
    const mobileToggle = document.querySelector('.mobile-menu-toggle');
    
    if (navMenu && mobileToggle) {
        navMenu.classList.add('mobile-active');
        mobileToggle.innerHTML = '✕';
        mobileToggle.style.fontSize = '1.8rem';
        
        // Add language switcher to mobile menu (only on launch pages)
        if (isLaunchPage() && !navMenu.querySelector('.language-switcher-mobile')) {
            const langSwitcherMobile = document.createElement('div');
            langSwitcherMobile.className = 'language-switcher-mobile';
            navMenu.appendChild(langSwitcherMobile);
            
            // Initialize mobile language switcher
            initializeMobileLanguageSwitcher();
        }
        
        console.log('📱 Mobile menu opened');
    }
}

function closeMobileMenu() {
    const navMenu = document.querySelector('.nav-menu');
    const mobileToggle = document.querySelector('.mobile-menu-toggle');
    
    if (navMenu && mobileToggle) {
        navMenu.classList.remove('mobile-active');
        mobileToggle.innerHTML = '☰';
        mobileToggle.style.fontSize = '1.5rem';
        console.log('📱 Mobile menu closed');
    }
}

// =============================================================================
// 6. MAIN UI OBJECT
// =============================================================================

const dcfUI = {
    initialize() {
        console.log('🚀 Initializing DCF UI System...');
        updateUserInterface();
        console.log('✅ DCF UI System initialized');
    },
    
    // Export functions for external use
    showAlert,
    showConfirm,
    showPrompt,
    populateTopNavigation,
    populateDCFNavigation,
    updateUserInterface,
    showLoggedOutState,
    isLaunchPage,
    hideLaunchPageElements,
    generateLogo,
    populateLogo,
    handleResponsiveLogo,
    initializeMobileMenu,
    toggleMobileMenu,
    openMobileMenu,
    closeMobileMenu
};

// Export to window for global access
window.dcfUI = dcfUI;
window.showAlert = showAlert;
window.showConfirm = showConfirm;
window.showPrompt = showPrompt;
window.closeAlert = closeAlert;
window.populateDCFNavigation = populateDCFNavigation;
window.isLaunchPage = isLaunchPage;
window.hideLaunchPageElements = hideLaunchPageElements;
window.generateLogo = generateLogo;
window.populateLogo = populateLogo;
window.handleResponsiveLogo = handleResponsiveLogo;
window.initializeMobileMenu = initializeMobileMenu;
window.toggleMobileMenu = toggleMobileMenu;
window.openMobileMenu = openMobileMenu;
window.closeMobileMenu = closeMobileMenu;
window.LOGO_CONFIG = LOGO_CONFIG; // Export config for easy access

// Make translation functions globally available
window.changeLanguage = changeLanguage;
window.t = t;
window.loadTranslations = loadTranslations;
window.applyTranslations = applyTranslations;
window.initializeTranslations = initializeTranslations;

console.log('✅ DCF UI system loaded');