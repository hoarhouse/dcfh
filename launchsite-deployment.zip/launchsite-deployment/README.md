# Domus Communis Foundation - Launchsite Deployment Package

## 📦 Package Contents

This deployment package contains the complete public-facing website for the Domus Communis Foundation, ready for deployment to GitHub Pages or any static hosting service.

### File Summary
- **98 HTML pages** - All public-facing content pages
- **5 JavaScript files** - Core functionality and UI
- **1 CSS file** - Styling for card components
- **2 Additional files** - Google verification and sitemap

### Directory Structure
```
launchsite-deployment/
├── index.html                 # Homepage
├── sitemap.xml               # Search engine sitemap
├── googlec5fda7e4a2520af5.html  # Google site verification
├── css/
│   └── dcf-card-templates.css
├── js/
│   ├── dcf-core.js          # Core functionality
│   ├── dcf-ui.js            # UI components
│   ├── dcf-auth.js          # Authentication
│   ├── dcf-init.js          # Initialization
│   └── dcf-analytics.js     # Analytics tracking
├── public/                  # 17 public info pages
├── blog/                    # 9 blog articles
├── faqs/                    # 22 FAQ pages
├── vatican-resources/       # 33 Vatican documents
├── initiatives/             # 6 initiative pages
├── people/                  # 1 people directory
├── events/                  # 3 event pages
├── projects/                # 3 project pages
└── resources/              # 3 resource pages
```

---

## 🚀 Deployment Instructions

### Option 1: GitHub Pages Deployment

1. **Create GitHub Repository**
   ```bash
   # Create new repository named 'dcfh' on GitHub
   # Then locally:
   git init
   git add .
   git commit -m "Initial launchsite deployment"
   git branch -M main
   git remote add origin https://github.com/hoarhouse/dcfh.git
   git push -u origin main
   ```

2. **Enable GitHub Pages**
   - Go to Settings → Pages in your repository
   - Source: Deploy from branch
   - Branch: main
   - Folder: / (root)
   - Click Save

3. **Custom Domain (if using)**
   - The CNAME file is already included
   - Add DNS records pointing to GitHub Pages:
     - A record: 185.199.108.153
     - A record: 185.199.109.153
     - A record: 185.199.110.153
     - A record: 185.199.111.153
     - CNAME record: hoarhouse.github.io

### Option 2: Static Hosting Deployment

Simply upload all files and folders to your web hosting service, maintaining the exact directory structure.

---

## ⚙️ Supabase Configuration

This site requires a Supabase backend for full functionality. Configure the following:

### 1. Environment Variables

Create a `.env` file or configure these in your hosting environment:

```javascript
// Add to js/dcf-core.js or create js/config.js
const SUPABASE_URL = 'YOUR_SUPABASE_PROJECT_URL';
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';
```

### 2. Required Supabase Tables

The site expects these tables in your Supabase database:

- `profiles` - User profiles
- `blog_posts` - Blog articles
- `resources` - Resource library items
- `events` - Event information
- `projects` - Project details
- `faqs` - FAQ content
- `vatican_resources` - Vatican document metadata

### 3. Storage Buckets

Configure these storage buckets:
- `avatars` - User profile images
- `blog-images` - Blog post images
- `resource-files` - Downloadable resources
- `project-images` - Project media

### 4. Authentication

Enable email authentication in Supabase:
- Dashboard → Authentication → Providers
- Enable Email provider
- Configure email templates for your domain

### 5. Row Level Security (RLS)

Enable RLS policies for public read access:
```sql
-- Example policy for public read access
CREATE POLICY "Public can read published content" 
ON blog_posts FOR SELECT 
USING (status = 'published');
```

---

## 🌐 CNAME Configuration

A CNAME file is included for GitHub Pages custom domain. 
Current configuration: `dcfh.hoarhouse.com`

To change the domain:
1. Edit the CNAME file with your domain
2. Configure DNS records as shown above

---

## ✅ Pre-Deployment Checklist

- [ ] Supabase project created and configured
- [ ] Environment variables set (Supabase URL & Key)
- [ ] CNAME file updated with correct domain
- [ ] DNS records configured (if using custom domain)
- [ ] Test all JavaScript files load correctly
- [ ] Verify CSS styling appears correct
- [ ] Check navigation works between pages
- [ ] Confirm Supabase connection successful

---

## 📝 Important Notes

1. **Dynamic Content**: Most images and some content are loaded dynamically from Supabase
2. **Authentication**: Public pages only - member areas not included in this package
3. **Relative Paths**: All internal links use relative paths for portability
4. **Browser Compatibility**: Tested on modern browsers (Chrome, Firefox, Safari, Edge)
5. **Mobile Responsive**: All pages are mobile-responsive

---

## 🔧 Troubleshooting

### Images Not Loading
- Check Supabase storage bucket permissions
- Verify CORS settings in Supabase

### JavaScript Errors
- Ensure all 5 JS files are present in /js/ directory
- Check browser console for specific errors
- Verify Supabase credentials are correct

### Pages Not Found (404)
- Confirm all files uploaded with correct directory structure
- Check file permissions (should be readable)
- Verify .html extensions are included in links

### Styling Issues
- Ensure dcf-card-templates.css is in /css/ directory
- Clear browser cache
- Check for CSS conflicts if integrating with existing site

---

## 📞 Support

For deployment assistance or technical questions:
- GitHub Issues: https://github.com/hoarhouse/dcfh/issues
- Documentation: See PUBLIC_LAUNCHSITE_MANIFEST.md

---

## 📄 License

Copyright © 2024 Domus Communis Foundation
All rights reserved.

---

*Deployment Package Version 1.0*
*Generated: November 2024*